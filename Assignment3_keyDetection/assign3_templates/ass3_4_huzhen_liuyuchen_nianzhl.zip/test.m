au=dir('/Users/onion/Downloads/genres/country/');
len=length(au);
for i=3:len
    